package exceptions;

public class SolicitacaoNaoEncontradaException extends Exception {
    public SolicitacaoNaoEncontradaException(String msg) {
        super(msg);
    }
}

