package service;

import model.Solicitacao;

public record listaSolicitacoes() {

    public static boolean removerPorId(int idSolicitacao) {
        throw new UnsupportedOperationException("Unimplemented method 'removerPorId'");
    }

    public static Solicitacao buscarPorId(int idSolicitacao) {
        throw new UnsupportedOperationException("Unimplemented method 'buscarPorId'");
    }

}
